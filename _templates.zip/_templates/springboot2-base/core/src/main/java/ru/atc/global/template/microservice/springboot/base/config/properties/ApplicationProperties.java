package ru.atc.global.template.microservice.springboot.base.config.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;

/**
 * Конфигурация приложения.
 */
@ConfigurationProperties(prefix = "app-config")
@Configuration
@Getter
@Setter
public class ApplicationProperties implements Serializable {

    private String appCode = "undefined";
}
