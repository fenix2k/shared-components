package ru.atc.global.template.microservice.springboot.base.controller;


import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.stereotype.Component;
import ru.atc.mvd.gismu.shared2.communication.openfeign.api.annotation.FeignGlobalInterceptor;

@FeignGlobalInterceptor
@Component
public class GlobalInterceptor implements RequestInterceptor {

    public static final String EXTERNAL_SYSTEM_REQUEST = "external-system";

    @Override
    public void apply(RequestTemplate template) {
        template.removeHeader(EXTERNAL_SYSTEM_REQUEST);
        template.header(EXTERNAL_SYSTEM_REQUEST, "true");
    }
}
