package ru.atc.global.template.microservice.springboot.base.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.atc.global.template.microservice.springboot.base.controller.LocalInterceptor;
import ru.atc.global.template.microservice.springboot.base.controller.Test1FeignClient;
import ru.atc.global.template.microservice.springboot.base.controller.Test2FeignClient;
import ru.atc.global.template.microservice.springboot.base.controller.TestFeignClient;
import ru.atc.mvd.gismu.shared2.communication.openfeign.api.FeignClientBuilder;
import ru.atc.mvd.gismu.shared2.communication.openfeign.api.config.FeignConfigComponents;

import java.util.Collections;

@Configuration
@RequiredArgsConstructor
public class FeignClientConfig {

    private final FeignClientBuilder feignClientBuilder;

    @Bean("TestFeignClient")
    public TestFeignClient testFeignClient(LocalInterceptor localInterceptor) {
        FeignConfigComponents components = FeignConfigComponents.builder()
                .requestInterceptors(Collections.singletonList(localInterceptor))
                .build();
        return feignClientBuilder.build(TestFeignClient.class, "test", components);
    }

    @Bean("Test1FeignClient")
    public Test1FeignClient test1FeignClient() {
        return feignClientBuilder.build(Test1FeignClient.class, "test1");
    }

    @Bean("Test2FeignClient")
    public Test2FeignClient test2FeignClient() {
        return feignClientBuilder.build(Test2FeignClient.class, "test2");
    }
}
