package ru.atc.global.template.microservice.springboot.base.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class QueryService {

    private final TestFeignClient client;
    private final Test1FeignClient client1;
    private final Test2FeignClient client2;

    public String doQuery() {
        String response = client.doRequest();
        log.info("response: {}", response);
        String response1 = client1.doRequest();
        log.info("response1: {}", response1);
        String response2 = client2.doRequest();
        log.info("response2: {}", response2);
        return response + ", " + response1 + ", " + response2;
    }
}
