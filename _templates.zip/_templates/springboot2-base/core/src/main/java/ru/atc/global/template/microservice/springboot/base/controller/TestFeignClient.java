package ru.atc.global.template.microservice.springboot.base.controller;

import feign.RequestLine;
import ru.atc.mvd.gismu.shared2.communication.openfeign.api.annotation.FeignService;

@FeignService(code = "test", url = "http://localhost:8099", name = "")
public interface TestFeignClient {

    @RequestLine("GET /api/demo")
    String doRequest();
}
