package ru.atc.global.template.microservice.springboot.base.controller;

import feign.RequestLine;

public interface Test2FeignClient {

    @RequestLine("GET /api/demo")
    String doRequest();
}
