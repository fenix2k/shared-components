package ru.atc.global.template.microservice.springboot.base.exception.enums;

import lombok.Getter;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.CommonExceptionCodes;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.ExceptionCode;
import ru.atc.mvd.gismu.shared2.exceptionhandler.spring.core.ExceptionCodes;

/**
 * Типы ошибок.
 */
@Getter
@SuppressWarnings("unused")
public class AppExceptionCodes extends ExceptionCodes {

    public static final ExceptionCode APP_COMMON_ERROR =
            new CommonExceptionCodes("1001", "APP", "Общая ошибка приложения");
    public static final ExceptionCode SOME_ERROR =
            new CommonExceptionCodes("1002", "APP", "Частная ошибка приложения");

    public AppExceptionCodes(String code, String type, String description) {
        super(code, type, description);
    }
}
