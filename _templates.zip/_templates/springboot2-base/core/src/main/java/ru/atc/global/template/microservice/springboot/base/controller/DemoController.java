package ru.atc.global.template.microservice.springboot.base.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.atc.global.template.microservice.springboot.base.exception.ApplicationException;
import ru.atc.mvd.gismu.shared2.exceptionhandler.spring.core.ExceptionCodes;

/**
 * Api контроллера demo контролера.
 */
@Tag(name = "Api контроллера demo контролера")
@RestController
@RequestMapping("/api/demo")
@RequiredArgsConstructor
public class DemoController {

    /**
     * Demo get string.
     */
    @GetMapping
    public String getString() {
        return "Какая-то строка";
    }

    /**
     * Demo throw exception.
     */
    @GetMapping("exception")
    public String throwException() {
        throw new ApplicationException(ExceptionCodes.ARGUMENT_EXCEPTION, "Какая-то ошибка", "Some error");
    }
}
