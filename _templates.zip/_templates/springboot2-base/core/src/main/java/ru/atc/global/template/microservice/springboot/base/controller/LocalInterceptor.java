package ru.atc.global.template.microservice.springboot.base.controller;


import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.stereotype.Component;

@Component
public class LocalInterceptor implements RequestInterceptor {

    public static final String LOCAL_SYSTEM_REQUEST = "local-system";

    @Override
    public void apply(RequestTemplate template) {
        template.removeHeader(LOCAL_SYSTEM_REQUEST);
        template.header(LOCAL_SYSTEM_REQUEST, "true");
    }
}
