package ru.atc.global.template.microservice.springboot.base.controller;

import feign.RequestLine;

public interface Test1FeignClient {

    @RequestLine("GET /api/demo")
    String doRequest();
}
