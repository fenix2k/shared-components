package ru.atc.global.template.microservice.springboot.mybatis.service;

@SuppressWarnings("unused")
class PersonServiceImplTest {
}