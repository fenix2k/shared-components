package ru.atc.global.template.microservice.springboot.mybatis.repository.api;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Общий CRUD репозиторий.
 *
 * @param <T> тип сущности
 * @param <ID> тип идентификатора сущности
 */
public interface CommonRepository<T, ID> {

    /** Получить все записи. */
    List<T> findAll();

    /** Получить запись по ID. */
    Optional<T> findById(ID id);

    /** Получить записи по ID. */
    List<T> findByIds(Set<ID> ids);

    /** Вставить новую запись. */
    int insert(T entity);

    /** Вставить новые записи. */
    int insertAll(Set<T> entities);

    /** Обновить запись. */
    int update(T entity);

    /** Удалить запись по ID. */
    int deleteById(ID id);

    /** Удалить записи по ID. */
    int deleteByIds(Set<ID> ids);
}
