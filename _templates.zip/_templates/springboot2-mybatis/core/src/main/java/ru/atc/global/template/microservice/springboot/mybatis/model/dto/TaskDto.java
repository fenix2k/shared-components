package ru.atc.global.template.microservice.springboot.mybatis.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ActionIndex;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Дто сущности "Задача".
 */
@Schema(description = "Дто сущности \"Задача\"")
@Data
@EqualsAndHashCode
public class TaskDto {

    @Schema(description = "Идентификатор")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    @Schema(description = "Заголовок")
    private String title;

    @Schema(description = "Описание")
    private String description;

    @Schema(description = "Срок выполнения")
    private LocalDateTime dueDttm;

    @Schema(description = "Признак выполнения")
    private Boolean isCompleted;

    @Schema(description = "Пользователь")
    private UserDto user;

    @Schema(description = "Группа задач")
    private TaskGroupDto taskGroup;

    @Schema(description = "Теги задач")
    private List<TaskTagDto> taskTags;

    @Schema(description = "Дата создания")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime createDttm;

    @Schema(description = "Дата изменения")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime modifyDttm;

    @Schema(description = "Индикатор изменения записи")
    private ActionIndex actionInd;
}
