package ru.atc.global.template.microservice.springboot.mybatis.model.api;

/**
 * Общий интерфейс сущности.
 */
public interface CommonEntity {
}
