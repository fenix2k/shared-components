package ru.atc.global.template.microservice.springboot.mybatis.model.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ExtendedEntityAttributes;

/**
 * Сущность "Группа задач".
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class TaskGroupEntity extends ExtendedEntityAttributes {

    /** Идентификатор. */
    private Long id;

    /** Название. */
    private String name;

    /** Пользователь. */
    private UserEntity user;
}
