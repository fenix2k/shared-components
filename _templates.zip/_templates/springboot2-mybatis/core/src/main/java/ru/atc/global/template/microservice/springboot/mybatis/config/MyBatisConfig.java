package ru.atc.global.template.microservice.springboot.mybatis.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("ru.atc.global.template.microservice.springboot.mybatis.repository")
public class MyBatisConfig {
}
