package ru.atc.global.template.microservice.springboot.mybatis.model.mapper;

import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.TaskTagDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.TaskTagEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.api.CommonMapper;

/**
 * Маппер для работы с сущностью "TaskTagEntity".
 */
@Mapper(componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED)
@SuppressWarnings("unused")
public interface TaskTagMapper extends CommonMapper<TaskTagEntity, TaskTagDto> {

    @Override
    void updateEntityFromDto(TaskTagDto dto, @MappingTarget TaskTagEntity entity);

    /**
     * Получение сущности по идентификатору.
     *
     * @param id идентификатор
     */
    TaskTagEntity toEntity(Long id);

    @Override
    TaskTagDto toDto(TaskTagEntity entity);
}
