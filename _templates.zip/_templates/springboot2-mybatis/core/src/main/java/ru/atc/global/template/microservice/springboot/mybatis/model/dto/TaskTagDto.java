package ru.atc.global.template.microservice.springboot.mybatis.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ActionIndex;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Дто сущности "Тег задачи".
 */
@Schema(description = "Дто сущности \"Тег задачи\"")
@Data
@EqualsAndHashCode
public class TaskTagDto {

    @Schema(description = "Идентификатор")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    @Schema(description = "Наименование")
    private String name;

    @Schema(description = "Задачи")
    private List<TaskDto> tasks;

    @Schema(description = "Дата создания")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime createDttm;

    @Schema(description = "Дата изменения")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime modifyDttm;

    @Schema(description = "Индикатор изменения записи")
    private ActionIndex actionInd;
}
