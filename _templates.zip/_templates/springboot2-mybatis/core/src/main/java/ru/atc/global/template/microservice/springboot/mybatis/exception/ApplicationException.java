package ru.atc.global.template.microservice.springboot.mybatis.exception;

import ru.atc.mvd.gismu.shared2.exceptionhandler.core.ExceptionCode;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.exceptions.AbstractRuntimeException;

/**
 * Исключение подсистемы.
 */
@SuppressWarnings("unused")
public class ApplicationException extends AbstractRuntimeException {

    private static final long serialVersionUID = 1L;

    public ApplicationException(ExceptionCode code, String message, String localizedMessage, Throwable ex) {
        super(code, message, localizedMessage, null, ex);
    }

    public ApplicationException(ExceptionCode code, String message, String localizedMessage) {
        super(code, message, localizedMessage, null, null);
    }

    public ApplicationException(ExceptionCode code, String message, String localizedMessage, Object details) {
        super(code, message, localizedMessage, details, null);
    }

    public ApplicationException(ExceptionCode code, String message, Throwable ex) {
        super(code, message, null, null, ex);
    }

    public ApplicationException(ExceptionCode code, String message) {
        super(code, message, null, null, null);
    }
}
