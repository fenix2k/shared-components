package ru.atc.global.template.microservice.springboot.mybatis.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ActionIndex;
import ru.atc.global.template.microservice.springboot.mybatis.model.enums.Genders;

import java.time.LocalDateTime;

/**
 * Дто сущности "Пользователь".
 */
@Schema(description = "Дто сущности \"Пользователь\"")
@Data
@EqualsAndHashCode
public class UserDto {

    @Schema(description = "Идентификатор")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    @Schema(description = "Имя")
    private String firstname;

    @Schema(description = "Фамилия")
    private String lastname;

    @Schema(description = "Пол")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Genders gender;

    @Schema(description = "Дата рождения")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime birthdateDttm;

    @Schema(description = "Дата создания")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime createDttm;

    @Schema(description = "Дата изменения")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime modifyDttm;

    @Schema(description = "Индикатор изменения записи")
    private ActionIndex actionInd;
}
