package ru.atc.global.template.microservice.springboot.mybatis.model.api;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Расширенные общие системные атрибуты.
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class ExtendedEntityAttributes extends SimpleEntityAttributes {

    /**
     * Индикатор изменения записи.
     */
    private ActionIndex actionInd = ActionIndex.I;
}