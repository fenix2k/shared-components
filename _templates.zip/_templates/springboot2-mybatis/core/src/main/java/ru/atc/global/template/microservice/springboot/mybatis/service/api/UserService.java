package ru.atc.global.template.microservice.springboot.mybatis.service.api;

import ru.atc.global.template.microservice.springboot.mybatis.model.dto.UserDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.UserEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.UserMapper;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Интерфейс сервиса "User".
 */
public interface UserService {

    /**
     * Получить маппер.
     *
     * @return {@link UserMapper}
     */
    UserMapper getMapper();

    /**
     * Получить все записи.
     *
     * @return {@link List}<{@link UserEntity}>
     */
    List<UserEntity> findAllEntity();

    /**
     * Получить запись по ID.
     *
     * @param id идентификатор
     * @return {@link Optional}<{@link UserEntity}>
     */
    Optional<UserEntity> findEntityById(long id);

    /**
     * Получить записи по ID.
     *
     * @param ids {@link Set}<{@link Long}>
     * @return {@link List}<{@link UserEntity}>
     */
    List<UserEntity> findEntitiesByIds(Set<Long> ids);

    /**
     * Вставить новую запись.
     *
     * @param entity {@link UserEntity}
     * @return кол-во вставленных строк
     */
    long insertEntity(UserEntity entity);

    /**
     * Вставить новые записи.
     *
     * @param entities {@link Set}<{@link UserEntity}>
     * @return кол-во вставленных строк
     */
    long insertEntities(Set<UserEntity> entities);

    /**
     * Обновить запись.
     *
     * @param entity {@link UserEntity}
     * @return кол-во обновлённых строк
     */
    long updateEntity(UserEntity entity);

    /**
     * Обновить записи.
     *
     * @param entities {@link Set}<{@link UserEntity}>
     * @return кол-во обновлённых строк
     */
    long updateEntities(Set<UserEntity> entities);

    /**
     * Удалить записи по ID.
     *
     * @param id идентификатор
     * @return кол-во удалённых записей
     */
    long deleteEntityById(long id);

    /**
     * Удалить запись по ID.
     *
     * @param ids {@link Set}<{@link Long}>
     * @return кол-во удалённых записей
     */
    long deleteEntitiesByIds(Set<Long> ids);

    /**
     * Получить все записи.
     *
     * @return {@link List}<{@link UserDto}>
     */
    List<UserDto> findAll();

    /**
     * Получить запись по ID.
     *
     * @param id идентификатор
     * @return {@link Optional}<{@link UserDto}>
     */
    Optional<UserDto> findById(long id);

    /**
     * Получить записи по ID.
     *
     * @param ids {@link Set}<{@link Long}>
     * @return {@link List}<{@link UserDto}>
     */
    List<UserDto> findByIds(Set<Long> ids);

    /**
     * Вставить новую запись.
     *
     * @param dto {@link UserDto}
     * @return {@link UserDto}
     */
    UserDto insert(UserDto dto);

    /**
     * Вставить новые записи.
     *
     * @param dtos {@link List}<{@link UserDto}>
     * @return {@link List}<{@link UserDto}>
     */
    List<UserDto> insertAll(List<UserDto> dtos);

    /**
     * Обновить запись.
     *
     * @param dto {@link UserDto}
     * @return {@link UserDto}
     */
    UserDto update(UserDto dto);

    /**
     * Обновить записи.
     *
     * @param dtos {@link List}<{@link UserDto}>
     * @return {@link List}<{@link UserDto}>
     */
    List<UserDto> updateAll(List<UserDto> dtos);
}
