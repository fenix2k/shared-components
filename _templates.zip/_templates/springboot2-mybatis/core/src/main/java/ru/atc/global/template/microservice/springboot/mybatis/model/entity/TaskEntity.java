package ru.atc.global.template.microservice.springboot.mybatis.model.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ExtendedEntityAttributes;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Сущность "Задача".
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class TaskEntity extends ExtendedEntityAttributes {

    /** Идентификатор. */
    private Long id;

    /** Заголовок. */
    private String title;

    /** Описание. */
    private String description;

    /** Срок выполнения. */
    private LocalDateTime dueDttm;

    /** Признак выполнения. */
    private Boolean isCompleted;

    /** Пользователь. */
    private UserEntity user;

    /** Группа задач. */
    private TaskGroupEntity taskGroup;

    /** Теги задач. */
    private List<TaskTagEntity> taskTags;
}
