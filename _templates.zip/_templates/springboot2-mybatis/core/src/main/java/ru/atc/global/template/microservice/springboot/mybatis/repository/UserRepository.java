package ru.atc.global.template.microservice.springboot.mybatis.repository;

import org.apache.ibatis.annotations.Mapper;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.UserEntity;
import ru.atc.global.template.microservice.springboot.mybatis.repository.api.CommonRepository;

/**
 * Репозиторий "Пользователя".
 */
@Mapper
public interface UserRepository extends CommonRepository<UserEntity, Long> {

//    /** Получить все записи. */
//    List<UserEntity> findAll();
//
//    /** Получить запись по ID. */
//    Optional<UserEntity> findById(long id);
//
//    /** Получить записи по ID. */
//    List<UserEntity> findByIds(Set<Long> ids);
//
//    /** Вставить новую запись. */
//    int insert(UserEntity entity);
//
//    /** Вставить новые записи. */
//    int insertAll(Set<UserEntity> entities);
//
//    /** Обновить запись. */
//    int update(UserEntity entity);
//
//    /** Удалить запись по ID. */
//    int deleteById(long id);
//
//    /** Удалить записи по ID. */
//    int deleteByIds(Set<Long> ids);
}
