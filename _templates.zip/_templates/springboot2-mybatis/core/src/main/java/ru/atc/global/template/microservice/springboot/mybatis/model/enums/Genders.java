package ru.atc.global.template.microservice.springboot.mybatis.model.enums;

/**
 * Пол.
 */
public enum Genders {

    MALE,
    FEMALE
}
