package ru.atc.global.template.microservice.springboot.mybatis.service;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.UserDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.UserEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.UserMapper;
import ru.atc.global.template.microservice.springboot.mybatis.repository.UserRepository;
import ru.atc.global.template.microservice.springboot.mybatis.service.api.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Реализация интерфейса сервиса "User".
 */
@Service
public class UserServiceImpl implements UserService {

    private final SqlSessionFactory sqlSessionFactory;
    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final UserServiceImpl self;

    public UserServiceImpl(SqlSessionFactory sqlSessionFactory, 
                           UserRepository userRepository, 
                           UserMapper userMapper, 
                           @Lazy UserServiceImpl self) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.userRepository = userRepository;
        this.userMapper = userMapper;
        this.self = self;
    }

    @Override
    public UserMapper getMapper() {
        return userMapper;
    }

    @Override
    public List<UserEntity> findAllEntity() {
        return userRepository.findAll();
    }

    @Override
    public Optional<UserEntity> findEntityById(long id) {
        return userRepository.findById(id);
    }

    @Override
    public List<UserEntity> findEntitiesByIds(Set<Long> ids) {
        return userRepository.findByIds(ids);
    }

    @Override
    public long insertEntity(UserEntity entity) {
        return userRepository.insert(entity);
    }

    @Override
    public long insertEntities(Set<UserEntity> entities) {
        return userRepository.insertAll(entities);
    }

    @Override
    public long updateEntity(UserEntity entity) {
        return userRepository.update(entity);
    }

    @Override
    public long updateEntities(Set<UserEntity> entities) {
        try (SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH)) {
            UserRepository mapper = sqlSession.getMapper(UserRepository.class);
            for (UserEntity entity : entities) {
                mapper.update(entity);
            }
            sqlSession.commit();
            return entities.size();
        }
    }

    @Override
    public long deleteEntityById(long id) {
        return userRepository.deleteById(id);
    }

    @Override
    public long deleteEntitiesByIds(Set<Long> ids) {
        return userRepository.deleteByIds(ids);
    }

    @Override
    public List<UserDto> findAll() {
        return userMapper.toDto(self.findAllEntity());
    }

    @Override
    public Optional<UserDto> findById(long id) {
        return self.findEntityById(id).map(getMapper()::toDto);
    }

    @Override
    public List<UserDto> findByIds(Set<Long> ids) {
        return getMapper().toDto(new ArrayList<>(self.findEntitiesByIds(ids)));
    }

    @Override
    public UserDto insert(UserDto dto) {
        UserEntity entity = userMapper.toEntity(dto);
        self.insertEntity(entity);
        return getMapper().toDto(entity);
    }

    @Override
    public List<UserDto> insertAll(List<UserDto> dtos) {
        Set<UserEntity> entities = dtos.stream()
                .map(userMapper::toEntity)
                .collect(Collectors.toSet());
        self.insertEntities(entities);
        return getMapper().toDto(new ArrayList<>(entities));
    }

    @Override
    public UserDto update(UserDto dto) {
        UserEntity entity = userMapper.toEntity(dto);
        self.updateEntity(entity);
        return getMapper().toDto(entity);
    }

    @Override
    public List<UserDto> updateAll(List<UserDto> dtos) {
        Set<UserEntity> entities = dtos.stream()
                .map(userMapper::toEntity)
                .collect(Collectors.toSet());
        self.updateEntities(entities);
        return getMapper().toDto(new ArrayList<>(entities));
    }
}
