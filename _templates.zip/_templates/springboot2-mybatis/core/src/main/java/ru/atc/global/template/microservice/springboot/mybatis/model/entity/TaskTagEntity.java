package ru.atc.global.template.microservice.springboot.mybatis.model.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ExtendedEntityAttributes;

import java.util.List;

/**
 * Сущность "Тег задачи".
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class TaskTagEntity extends ExtendedEntityAttributes {

    /** Идентификатор. */
    private Long id;

    /** Наименование. */
    private String name;

    /** Задачи. */
    private List<TaskEntity> tasks;
}
