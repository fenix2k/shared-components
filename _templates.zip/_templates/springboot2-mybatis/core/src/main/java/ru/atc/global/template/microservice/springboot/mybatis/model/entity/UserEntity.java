package ru.atc.global.template.microservice.springboot.mybatis.model.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import ru.atc.global.template.microservice.springboot.mybatis.model.api.ExtendedEntityAttributes;
import ru.atc.global.template.microservice.springboot.mybatis.model.enums.Genders;

import java.time.LocalDateTime;

/**
 * Сущность "Пользователь".
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class UserEntity extends ExtendedEntityAttributes {

    /** Идентификатор. */
    private Long id;

    /** Имя. */
    private String firstname;

    /** Фамилия. */
    private String lastname;

    /** Пол. */
    private Genders gender;

    /** Дата рождения. */
    private LocalDateTime birthdateDttm;
}
