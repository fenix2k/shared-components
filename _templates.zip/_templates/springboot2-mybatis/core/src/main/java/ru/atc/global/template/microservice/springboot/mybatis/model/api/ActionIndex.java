package ru.atc.global.template.microservice.springboot.mybatis.model.api;

/**
 * Значения индикатора изменения строки в таблице.
 */
public enum ActionIndex {

    /** Создана новая записи. */
    I,

    /** Запись была обновлена. */
    U,

    /** Запись была удалена (помечена как удалённая). */
    D
}