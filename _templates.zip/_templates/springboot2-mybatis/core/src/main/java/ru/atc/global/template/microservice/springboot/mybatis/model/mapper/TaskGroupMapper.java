package ru.atc.global.template.microservice.springboot.mybatis.model.mapper;

import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.TaskGroupDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.TaskGroupEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.api.CommonMapper;

/**
 * Маппер для работы с сущностью "TaskGroupEntity".
 */
@Mapper(componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED)
@SuppressWarnings("unused")
public interface TaskGroupMapper extends CommonMapper<TaskGroupEntity, TaskGroupDto> {

    @Override
    void updateEntityFromDto(TaskGroupDto dto, @MappingTarget TaskGroupEntity entity);

    /**
     * Получение сущности по идентификатору.
     *
     * @param id идентификатор
     */
    TaskGroupEntity toEntity(Long id);

    @Override
    TaskGroupDto toDto(TaskGroupEntity entity);
}
