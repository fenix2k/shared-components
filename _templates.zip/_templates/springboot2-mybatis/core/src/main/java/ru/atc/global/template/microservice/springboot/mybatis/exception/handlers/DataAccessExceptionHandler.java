package ru.atc.global.template.microservice.springboot.mybatis.exception.handlers;

import org.springframework.expression.AccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.dto.CommonErrorMessageDto;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.handlers.AbstractExceptionHandler;
import ru.atc.mvd.gismu.shared2.exceptionhandler.core.handlers.ExceptionHandler;

/**
 * Обработчик по-умолчанию.
 */
@Component
public class DataAccessExceptionHandler extends AbstractExceptionHandler
        implements ExceptionHandler {

    @Override
    public Class<? extends Exception> exceptionClass() {
        return AccessException.class;
    }

    @Override
    public void afterBuildErrorMessage(CommonErrorMessageDto errorMessage) {
        errorMessage.setStatus(HttpStatus.BAD_REQUEST.value());
    }
}
