package ru.atc.global.template.microservice.springboot.mybatis.model.mapper;

import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.TaskDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.TaskEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.api.CommonMapper;

/**
 * Маппер для работы с сущностью "TaskEntity".
 */
@Mapper(componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED)
@SuppressWarnings("unused")
public interface TaskMapper extends CommonMapper<TaskEntity, TaskDto> {

    @Override
    void updateEntityFromDto(TaskDto dto, @MappingTarget TaskEntity entity);

    /**
     * Получение сущности по идентификатору.
     *
     * @param id идентификатор
     */
    TaskEntity toEntity(Long id);

    @Override
    TaskDto toDto(TaskEntity entity);
}
