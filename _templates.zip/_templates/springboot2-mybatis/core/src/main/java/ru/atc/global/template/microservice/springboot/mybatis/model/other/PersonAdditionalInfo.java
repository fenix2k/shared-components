package ru.atc.global.template.microservice.springboot.mybatis.model.other;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Дополнительная информация.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PersonAdditionalInfo implements Serializable {

    private String address;
}
