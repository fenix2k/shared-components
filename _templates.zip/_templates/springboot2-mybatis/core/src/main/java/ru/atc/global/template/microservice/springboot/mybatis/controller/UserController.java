package ru.atc.global.template.microservice.springboot.mybatis.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.UserDto;
import ru.atc.global.template.microservice.springboot.mybatis.service.api.UserService;

import java.util.List;
import java.util.Set;

/**
 * Api контроллера для работы с сущностью User.
 */
@Tag(name = "Api контроллера для работы с сущностью User")
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /**
     * Сохранить/обновить объект.
     *
     * @param dto {@link UserDto}
     * @return {@link UserDto}
     */
    @Operation(summary = "Сохранить/обновить объект")
    @PostMapping
    public UserDto save(@RequestBody UserDto dto) {
        return dto.getId() == null ? userService.insert(dto) : userService.update(dto);
    }

    /**
     * Сохранить объекты.
     *
     * @param dtos {@link List}<{@link UserDto}>
     * @return {@link List}<{@link UserDto}>
     */
    @Operation(summary = "Сохранить объекты")
    @PostMapping("create-batch")
    public List<UserDto> createBatch(@RequestBody List<UserDto> dtos) {
        return userService.insertAll(dtos);
    }

    /**
     * Обновить объекты.
     *
     * @param dtos {@link List}<{@link UserDto}>
     * @return {@link List}<{@link UserDto}>
     */
    @Operation(summary = "Обновить объекты")
    @PostMapping("update-batch")
    public List<UserDto> updateBatch(@RequestBody List<UserDto> dtos) {
        return userService.updateAll(dtos);
    }

    /**
     * Удалить объект.
     *
     * @param id идентификатор объекта
     * @return кол-во удалённых записей
     */
    @Operation(summary = "Удалить объект")
    @DeleteMapping("/{id}")
    public long deleteById(@PathVariable("id") Long id) {
        return userService.deleteEntityById(id);
    }

    /**
     * Удалить объекты.
     *
     * @param ids {@link Set}<{@link Long}>
     * @return кол-во удалённых записей
     */
    @Operation(summary = "Удалить объекты")
    @DeleteMapping("byIds")
    public long deleteByIds(@RequestParam("ids") Set<Long> ids) {
        return userService.deleteEntitiesByIds(ids);
    }

    /**
     * Получить объект по его идентификатору.
     *
     * @param id идентификатор объекта
     * @return {@link UserDto}
     */
    @Operation(summary = "Получить объект по его идентификатору")
    @GetMapping("/{id}")
    public UserDto getById(@PathVariable("id") Long id) {
        return userService.findById(id)
                .orElse(null);
    }

    /**
     * Получить объекты по идентификаторам.
     *
     * @param ids {@link Set}<{@link Long}>
     * @return {@link List}<{@link UserDto}>
     */
    @Operation(summary = "Получить объекты по идентификаторам")
    @GetMapping("byIds")
    public List<UserDto> getByIds(@RequestParam("ids") Set<Long> ids) {
        return userService.findByIds(ids);
    }

    /**
     * Получить список объектов постранично.
     *
     * @return {@link List}<{@link UserDto}>
     */
    @Operation(summary = "Получить список объектов постранично")
    @GetMapping("")
    public List<UserDto> findAll() {
        return userService.findAll();
    }

//    /**
//     * Поиск по параметрам объекта.
//     *
//     * @param searchParams параметры поиска {@link PersonSearchParam}
//     * @param pageable параметры пагинации {@link Pageable}
//     * @return {@link Page}<{@link PersonDto}>
//     */
//    @Operation(summary = "Поиск по параметрам объекта")
//    @PostMapping("/search")
//    public Page<PersonDto> search(@RequestBody PersonSearchParam searchParams,
//                                  @ParameterObject Pageable pageable) {
//        return personService.search(searchParams, pageable);
//    }
}
