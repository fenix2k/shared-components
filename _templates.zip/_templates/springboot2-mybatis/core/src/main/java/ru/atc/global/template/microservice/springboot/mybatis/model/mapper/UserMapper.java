package ru.atc.global.template.microservice.springboot.mybatis.model.mapper;

import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import ru.atc.global.template.microservice.springboot.mybatis.model.dto.UserDto;
import ru.atc.global.template.microservice.springboot.mybatis.model.entity.UserEntity;
import ru.atc.global.template.microservice.springboot.mybatis.model.mapper.api.CommonMapper;

/**
 * Маппер для работы с сущностью "UserEntity".
 */
@Mapper(componentModel = "spring",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        collectionMappingStrategy = CollectionMappingStrategy.ADDER_PREFERRED)
@SuppressWarnings("unused")
public interface UserMapper extends CommonMapper<UserEntity, UserDto> {

    @Override
    void updateEntityFromDto(UserDto dto, @MappingTarget UserEntity entity);

    /**
     * Получение сущности по идентификатору.
     *
     * @param id идентификатор
     */
    UserEntity toEntity(Long id);

    @Override
    UserDto toDto(UserEntity entity);
}
