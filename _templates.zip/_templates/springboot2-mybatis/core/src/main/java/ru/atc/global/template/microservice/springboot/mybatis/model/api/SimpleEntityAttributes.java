package ru.atc.global.template.microservice.springboot.mybatis.model.api;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Базовые общие системные атрибуты.
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@SuppressWarnings("unused")
public abstract class SimpleEntityAttributes implements CommonEntity {

    /**
     * Дата создания.
     */
    private LocalDateTime createDttm;

    /**
     * Дата изменения.
     */
    private LocalDateTime modifyDttm;
}
