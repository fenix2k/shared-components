create table if not exists mm_tasks_task_tags
(
    task_id     bigint not null,
    task_tag_id bigint not null,
    constraint mm_tasks_task_tags_pk primary key (task_id, task_tag_id)
);

comment on table mm_tasks_task_tags is 'Теги задач';
comment on column mm_tasks_task_tags.task_id is 'Идентификатор задачи';
comment on column mm_tasks_task_tags.task_tag_id is 'Идентификатор тега задачи';