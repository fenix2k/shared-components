create sequence if not exists users_seq start 1 increment 1;

create table if not exists users
(
    id       bigint       not null default nextval('person_seq'),
    firstname       varchar(255) not null,
    lastname        varchar(255) not null,
    gender          varchar(20)  not null,
    birthdate_dttm  timestamptz  not null,
    create_dttm     timestamptz  not null default now(),
    modify_dttm     timestamptz  not null default now(),
    action_ind      varchar(1)   not null default 'I',
    constraint users_pk primary key (id)
);

comment on table users is 'Пользователь';
comment on column users.id is 'Идентификатор';
comment on column users.firstname is 'Имя';
comment on column users.lastname is 'Фамилия';
comment on column users.gender is 'Пол';
comment on column users.birthdate_dttm is 'Дата рождения';
comment on column users.create_dttm is 'Дата время вставки записи в таблицу';
comment on column users.modify_dttm is 'Дата время изменения записи';
comment on column users.action_ind is 'Идентификатор последнего действия';