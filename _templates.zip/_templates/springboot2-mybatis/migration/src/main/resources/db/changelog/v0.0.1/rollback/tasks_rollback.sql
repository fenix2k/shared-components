drop table if exists tasks;

drop sequence if exists tasks_seq;