drop table if exists users;

drop sequence if exists users_seq;