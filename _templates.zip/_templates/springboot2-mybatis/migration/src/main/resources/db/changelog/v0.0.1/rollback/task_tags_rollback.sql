drop table if exists task_tags;

drop sequence if exists task_tags_seq;