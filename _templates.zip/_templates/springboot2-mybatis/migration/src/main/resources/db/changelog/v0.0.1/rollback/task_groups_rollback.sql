drop table if exists task_groups;

drop sequence if exists task_groups_seq;