create sequence if not exists task_groups_seq start 1 increment 1;

create table if not exists task_groups
(
    id          bigint       not null default nextval('task_groups_seq'),
    user_id     bigint       not null,
    name        varchar(255) not null,
    create_dttm timestamptz  not null default now(),
    modify_dttm timestamptz  not null default now(),
    action_ind  varchar(1)   not null default 'I',
    constraint task_groups_pk primary key (id),
    constraint task_groups_users_fk foreign key (id)
        references users (id)
);

comment on table task_groups is 'Группы задач';
comment on column task_groups.id is 'Идентификатор';
comment on column task_groups.user_id is 'Идентификатор пользователя';
comment on column task_groups.name is 'Название';
comment on column task_groups.create_dttm is 'Дата время вставки записи в таблицу';
comment on column task_groups.modify_dttm is 'Дата время изменения записи';
comment on column task_groups.action_ind is 'Идентификатор последнего действия';