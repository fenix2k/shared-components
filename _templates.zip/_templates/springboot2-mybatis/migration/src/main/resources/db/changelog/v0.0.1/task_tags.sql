create sequence if not exists task_tags_seq start 1 increment 1;

create table if not exists task_tags
(
    id          bigint      not null default nextval('task_tags_seq'),
    name        bigint      not null,
    create_dttm timestamptz not null default now(),
    modify_dttm timestamptz not null default now(),
    action_ind  varchar(1)  not null default 'I',
    constraint task_tags_pk primary key (id)
);

comment on table task_tags is 'Теги задач';
comment on column task_tags.id is 'Идентификатор';
comment on column task_tags.name is 'Наименование';
comment on column task_tags.create_dttm is 'Дата время вставки записи в таблицу';
comment on column task_tags.modify_dttm is 'Дата время изменения записи';
comment on column task_tags.action_ind is 'Идентификатор последнего действия';