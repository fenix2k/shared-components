create sequence if not exists tasks_seq start 1 increment 1;

create table if not exists tasks
(
    id            bigint        not null default nextval('tasks_seq'),
    user_id       bigint        not null,
    task_group_id bigint        not null,
    title         varchar(255)  not null,
    description   varchar(1024) not null,
    due_dttm      timestamptz,
    is_completed  bool                   default false,
    create_dttm   timestamptz   not null default now(),
    modify_dttm   timestamptz   not null default now(),
    action_ind    varchar(1)    not null default 'I',
    constraint tasks_pk primary key (id),
    constraint tasks_users_fk foreign key (id)
        references users (id),
    constraint tasks_task_groups_fk foreign key (id)
        references task_groups (id)
);

comment on table tasks is 'Задача';
comment on column tasks.id is 'Идентификатор';
comment on column tasks.user_id is 'Идентификатор пользователя';
comment on column tasks.title is 'Заголовок';
comment on column tasks.description is 'Описание';
comment on column tasks.due_dttm is 'Срок выполнения';
comment on column tasks.is_completed is 'Признак выполнения';
comment on column tasks.create_dttm is 'Дата время вставки записи в таблицу';
comment on column tasks.modify_dttm is 'Дата время изменения записи';
comment on column tasks.action_ind is 'Идентификатор последнего действия';